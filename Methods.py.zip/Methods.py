#!/usr/bin/env python
# coding: utf-8

# In[1]:


#libraries used: 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder
from scipy.stats import chisquare


"""
DATA CLEANING AND PROCESSING:
Data manipulation, cleaning, and processing for statistical computation, 
and data vizualization. 

"""

""" Data Cleaning: 

AgeToBins: takes in a demographical dataset with age column
and categorizes them

"""
def ageToBins(new,AGE):
    #change type to be same for all entries (float), then change to int
    new['AGE'] = new['AGE'].astype(float).astype(int)

    #manipulate age into bins
    new.loc[new['AGE'] <= 20, 'AGE'] = 0
    new.loc[(new['AGE'] > 20) & (new['AGE'] <= 40), 'AGE'] = 1
    new.loc[(new['AGE'] > 40) & (new['AGE'] <= 60), 'AGE'] = 2
    new.loc[(new['AGE'] > 60) & (new['AGE'] <= 80), 'AGE'] = 3
    new.loc[(new['AGE'] > 80) & (new['AGE'] <= 100), 'AGE'] = 4
    new.loc[(new['AGE'] > 100) & (new['AGE'] <= 120), 'AGE'] = 5
    
    return new

""" Data Cleaning: 

ohe_co: takes in a demographical dataset with column to be one hot encoded

"""
#one hot encode function
def ohe_col(data, col):
    enc = OneHotEncoder()
    enc.fit(data[[col]])
    new = pd.DataFrame(enc.transform(data[[col]]).todense(),
                      columns = enc.get_feature_names(),
                      index = data.index)
    return data.join(new)

""" 
Data Cleaning/Prepping:

Process: takes in a demographical dataset 
df and does  nessesary cleaning to dataframe. 
The following demogrpahical is used and altered: 

Age : categorizing it in increments of 20 from ages 0 to 120
for example ,.0-20 = 0 , 20 -40 =1,..., ect. 

Gender: binarizes sex where M = 0 and F=1

House-Hold income: categorizes household income range[0,7). 
The data is incremented $50,000 per category
For example: $30,000 to $49,999': 1

Education: 
gategorizes education level of consumer 
'not_reported': 0,
'High School': 1,
'Vocational_or_Technical': 2,
'College': 3,
'Graduate School': 4
"""

def process(df):
    
    df = df.dropna(axis = 0)
    df['AGE'] = df['AGE'].astype(float).astype(int)
    
    df.loc[df['AGE'] <= 20, 'AGE'] = 0
    df.loc[(df['AGE'] > 20) & (df['AGE'] <= 40), 'AGE'] = 1
    df.loc[(df['AGE'] > 40) & (df['AGE'] <= 60), 'AGE'] = 2
    df.loc[(df['AGE'] > 60) & (df['AGE'] <= 80), 'AGE'] = 3
    df.loc[(df['AGE'] > 80) & (df['AGE'] <= 100), 'AGE'] = 4
    df.loc[(df['AGE'] > 100) & (df['AGE'] <= 120), 'AGE'] = 5
    
    factor_dict = {
        'GENDER': {
            'M': 0,
            'F': 1
        },
        'HOMEOWNERSHIP_STATUS': {
            'Homeowner': 1,
            'Renter': 0
        },
        'DEMO_HH_INCOME': {
            'Less than $30,000': 0,
            '$30,000 to $49,999': 1, 
            '$50,000 to $74,999': 2,
            '$75,000 to $99,999': 3,
            '$100,000 to $149,999': 4,
            '$150,000 to $199,999': 5,
            '$200,000 to $249,999': 6,
            '$250,000 +': 7
        },
        'EDUCATION': {
            'not_reported': 0,
            'High School': 1,
            'Vocational_or_Technical': 2,
            'College': 3,
            'Graduate School': 4
        }
    }
    df = df.replace(factor_dict)
    
    df = ohe_col(df, 'ETHNICITY')
    df = ohe_col(df, 'DMA_NAME_ACXIOM')
    
    df = df.set_index('Unnamed: 0')
    df = df.drop(['ZIP', 'STATE_ABBREVIATION', 'DMA_NAME_ACXIOM', 'ETHNICITY'], axis = 1)
    
    return df

""" 
finalDF:
dataframe with all the manipulations/slices
"""
def finalDF(df, featureDict):
    for column in featureDict.keys():
        new_df = pd.DataFrame()
        attributes = featureDict[column]
        for attribute in attributes:
            new_df = new_df.append(df[df[column] == attribute])
        df = new_df
    return df


"""
Data cleaning:

step by step slicing 
(same as finalDF except only considering one column slice at a time)


"""
def stepSlice(df, featureDict, column):
    new_df = pd.DataFrame()
    attributes = featureDict[column]
    for attribute in attributes:
        new_df = new_df.append(df[df[column] == attribute])
    df = new_df
    return df


"""Data Cleaning:
replace nans with desired value
"""
def replace_nan_with_value(x, y, value):
    x = np.array([v if v == v and v is not None else value for v in x])  # NaN != NaN
    y = np.array([v if v == v and v is not None else value for v in y])
    return x, y

"""
DataCleaning:
removing incomplete samples from dataset
"""
def remove_incomplete_samples(x, y):
    x = [v if v is not None else np.nan for v in x]
    y = [v if v is not None else np.nan for v in y]
    arr = np.array([x, y]).transpose()
    arr = arr[~np.isnan(arr).any(axis=1)].transpose()
    if isinstance(x, list):
        return arr[0].tolist(), arr[1].tolist()
    else:
        return arr[0], arr[1]

    
"""
Data processing: 
encode:
encode selected features to match processed data frame
"""
def encode(featureDict, encodeDict):
    encodedFeatures = {}
    for column in featureDict.keys():
        attributes = featureDict[column]
        if column in encodeDict.keys():
            encodedAttributes = list()
            for attribute in attributes:
                newAttribute = encodeDict[column][attribute]
                encodedAttributes.append(newAttribute)
            encodedFeatures[column] = encodedAttributes
        else:
            encodedFeatures[column] = attributes
    return encodedFeatures

""" 
Data Processing: 

The following methods are used to return dataframes based on cities

"""

def cityDataFrames(df, city, dmaName):
    return df[df[dmaName] == city]

def altCityDataFrames(df, city, dmaName):
    grouped = df.groupby(dmaName)
    return grouped.get_group(city)

def allCitiesList(df,dmaName ):
    cities = df[dmaName].unique()
    dfList = []
    for city in cities:
        city = df[df[dmaName] == city]
        dfList.append(city)
    return dfList

def allCitiesDict(df, dmaName):
    cities = df[dmaName].unique()
    dfDict = {}
    for city in cities:
        cityName = city
        city = df[df[dmaName] == cityName]
        dfDict[cityName] = city
    return dfDict



"""
STATISTICAL COMPUTATION METHODS:
These methods will help produce insightful information to user on dashboard 
using statistical computations such as Chi-square and correlation matrices 

"""


"""
Statistical Computations:

Using seaborn, takes two tables, iterates through the columns 
and generates the chi-square statistic for each column's 
frequencies. assumes categorical variable. 

get_chis: 
Calculates Chi-Square between two different features of demographical data

show_chis:
displays calculated Chi-Sqaures between two tables

"""


def get_chis(table1,table2):
    column_chi = {}
    for column in table1.columns[2:]:
        chi = ss.chisquare(table1[column].value_counts(), table2[column].value_counts())
        column_chi[column] = chi
    return column_chi

def show_chis(table1,table2):
    test = get_chis(table1,table2)
    for column in sample1.columns[2:]:
        
        print(column + ':' + str(test[column]))
        
        
"""
Statistical Methods:
corrMatrix: 
takes in dataframe creates correlation matrix using seaborn.
"""
def corrMatrix(df):
    return df.corr()




"""
VIZUALIZING STATISTICAL COMPUTATION METHODS:
These methods will help produce insightful plots to user on dashboard 
using statistical computations such as Chi-square and correlation matrices 
"""

"""
vizualizing Statistical Methods:
Prints user friendly vizualizations of dataframe using:
- Chi_Square 
- P-values
as computation 

"""
def print_charts(orig, new, col_name, order):
    
    #pie chart for original dataset
    labels_orig = pd.DataFrame(orig[col_name]
                .value_counts(normalize=True)).reset_index().iloc[:, 0]
    sizes_orig = pd.DataFrame(orig[col_name]
                .value_counts(normalize=True)).reset_index().iloc[:, 1] * 100
    
    fig_orig = make_subplots(rows = 1, cols = 2, 
            subplot_titles=(col_name + ": Original", col_name + ": New"))
    fig_orig.add_trace(go.Bar(x = labels_orig, y=sizes_orig, name = 'Original'), row = 1, col = 1)
    
    #pie chart for new dataset
    
    sizes_new = []
    for i in labels_orig:
        sizes_new = np.append(sizes_new, (len(new[new[col_name] == i])/len(new[col_name]))*100)
    
    fig_orig.add_trace(go.Bar(x = labels_orig, y=sizes_new, name = "New"), row = 1, col = 2)
    
    fig_orig.update_xaxes(categoryorder = 'array', categoryarray = order)
    
    diff, pval = chisquare(sizes_orig, sizes_new)
    
    fig_orig.update_layout(height=350, width=700, 
                title_text="Change in " + col_name + 
                ". Chi squared difference: " + str(round(diff, 3)) +
                ". P_value: " + str(round(pval, 3)) )
    
    fig_orig.update_yaxes(range=[0,max(max(sizes_orig), max(sizes_new)) + 5])
    
    fig_orig.update_yaxes(tickvals = np.arange(0,101, 10))
    
    fig_orig.show()
    
    
    
    """
    vizualizing Statistical Methods:
    Displays charts using Demographical Data by calling print_charts method
    
    """
    

    def show_charts(orig, new):
    
    # DEMO_HH_INCOME
    print_charts(orig, new, "DEMO_HH_INCOME", ['Less than $30,000','30,000 to 49,999',
                                                   '50,000 to 74,999','75,000 to 99,999',
                                                   '100,000 to 149,999', '150,000 to 199,999',
                                                   '200,000 to 249,999', '$250,000 +'])

    #GENDER
    print_charts(orig, new, "GENDER", ['F', 'M'])
    
    
    #HOMEOWNERSHIP_STATUS
    print_charts(orig, new, "HOMEOWNERSHIP_STATUS", ['Homeowner', 'Renter'])
    
    #EDUCATION
    print_charts(orig, new, "EDUCATION", ['High School', 'College', 'Graduate School', 'Vocational_or_Technical', 'not_reported'])
    
    #ETHNICITY
    print_charts(orig, new, "ETHNICITY", np.unique(orig['ETHNICITY']))
    
    
    #DMA_NAME_ACXIOM
    
    print_charts(orig, new, "DMA_NAME_ACXIOM", np.unique(orig["DMA_NAME_ACXIOM"]))

    plt.show()
    

